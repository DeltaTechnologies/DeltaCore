Put all files of this folder in the main exploit folder, then run the exe u want

Additional Credits for the optional UI:
LittleKiller
OrbitRBX
Sentinel Devs